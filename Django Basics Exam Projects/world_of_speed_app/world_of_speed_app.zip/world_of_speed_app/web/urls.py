from django.urls import path

from world_of_speed_app.web.views import index, create_profile

urlpatterns = (
    path("", index, name="index"),
    path("create-profile/", create_profile, name="create_profile"),

)
