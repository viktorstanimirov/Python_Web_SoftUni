from django.shortcuts import render, redirect

from world_of_speed_app.web.forms import CreateProfileForm


def create_profile(request):
    if request.method == 'POST':
        form = CreateProfileForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('catalogue')
    else:
        form = CreateProfileForm()

    return render(request, "profiles/profile-create.html", {'form': form})


def index(request):

    return render(request, "web/index.html")
